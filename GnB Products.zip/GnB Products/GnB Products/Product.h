//
//  Product.h
//  GnB Products
//
//  Created by Salma Khattab on 8/20/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Product)

@property (nonatomic, readonly) int ID;
@property (nonatomic, readonly) id productDescription;
@property (nonatomic, readonly) id url;
@property (nonatomic, readonly) int width;
@property (nonatomic, readonly) int height;
@property (nonatomic, readonly) double price;

@end

@interface NSMutableDictionary (Product)

@property (nonatomic, readwrite) id productImage;
@property (nonatomic, readwrite) BOOL addedToMyList;

@end

