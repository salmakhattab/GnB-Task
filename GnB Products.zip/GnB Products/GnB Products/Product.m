//
//  Product.m
//  GnB Products
//
//  Created by Salma Khattab on 8/20/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "Product.h"

@implementation NSDictionary (Product)


- (id)productDescription {
    
    return self[@"productDescription"];
}

- (id)url {
    
    return self[@"url"];
}

- (double)price {
    
    return  [self[@"price"] doubleValue];
}

- (int)ID {
    
    return  [self[@"id"] intValue];
}

- (int)width {
    
    return  [self[@"width"] intValue];
}

- (int)height {
    
    return  [self[@"height"] intValue];
}

@end
