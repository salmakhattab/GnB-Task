//
//  VerticalCollectionViewCell.m
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "VerticalCollectionViewCell.h"
#import "Product.h"

@implementation VerticalCollectionViewCell

- (void)setProduct:(NSMutableDictionary *)product {
    
    _product = product;
    [self.imageButton setBackgroundImage:[[UIImage alloc] initWithData:product.productImage] forState:UIControlStateNormal];
    [self.imageButton setTitle:@(product.price).description forState:UIControlStateNormal];
    self.describtionLAbel.text = product.productDescription;
    if(product.addedToMyList) [self.addToMyListButton setTitle:@"On my list" forState:UIControlStateNormal];
    else [self.addToMyListButton setTitle:@"Add to my list" forState:UIControlStateNormal];
}

- (IBAction)addToMyListButtonTapped:(id)sender {
    
    if(_product.addedToMyList)
        _product.addedToMyList = NO;
    else
        _product.addedToMyList = YES;
    
    if(_mainViewController.addToMyList) {
        
        _mainViewController.addToMyList(_product.addedToMyList , _index);
    }
}

@end
