//
//  ViewController.m
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "MainViewController.h"
#import "ServiceConnector.h"
#import "DataOperation.h"

@interface MainViewController ()

@end

@implementation MainViewController {
    
    DataOperation *productsOpeartion;
    ServiceConnector *serviceConnector;
    NSMutableArray *productList;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    productList = [NSMutableArray array];
    productsOpeartion = [[DataOperation alloc] init];
    serviceConnector = [[ServiceConnector alloc] init];
    productsOpeartion.url = @"http://grapesnberries.getsandbox.com/products?count=5&from=0";
    productsOpeartion.notification = @"NotificationForProducts";
    productsOpeartion.method = @"GET";
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(useNotificationForProducts:) name:productsOpeartion.notification object:nil];
    [serviceConnector executeOperation:productsOpeartion];
    
}

- (void)viewDidAppear:(BOOL)animated{
    
//     [self performSegueWithIdentifier:@"showProductDetails" sender:nil];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return 8;
}

 - (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
     
     return collectionView == self.featuredCollectionView ? CGSizeMake(self.view.bounds.size.width/5 , 100) : CGSizeMake(self.view.bounds.size.width, 250);
 }
 
 - (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(nonnull UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
 
     //top, left, bottom, right
     return collectionView == self.featuredCollectionView ? UIEdgeInsetsMake(0, 0, 0, 16) : UIEdgeInsetsMake(16 , 16, 16, 16) ;
 }

 
 - (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {

     return 5;
 }
 
 - (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
 {
     NSString *celIdentifier = collectionView == self.featuredCollectionView ? @"FeaturedCell" : @"ProductCell";
     UICollectionViewCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:celIdentifier forIndexPath:indexPath];
     if (!cell) {
     
            cell  = [collectionView dequeueReusableCellWithReuseIdentifier:celIdentifier forIndexPath:indexPath];
     }
     return cell;
 }

- (void)useNotificationForProducts:(NSNotification *)notif {
    
    NSDictionary *dict = [notif userInfo];
    NSError *error = [(DataOperation *) [dict valueForKey:@"Operation"] error];
    if (!error) {
        
        NSArray *List = [(DataOperation *) [dict valueForKey:@"Operation"] response];
        NSLog(@"%@", List);
        
        for (NSDictionary* dic in List) {
            
            NSMutableDictionary *productDict = [NSMutableDictionary dictionary];
            for (NSString* key1 in dic) {
                
                if ([dic[key1] isKindOfClass:[NSDictionary class]]) {
                    
                    for (NSString* key2 in dic[key1]) {
                        
                        [productDict setObject:dic[key1][key2] forKey:key2];
                    }
                } else {
                    
                    [productDict setObject:dic[key1] forKey:key1];
                }
            }
            [productList addObject:productDict];
        }
     
    } else {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:error.description preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okButton = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [alert addAction:okButton];
        [self presentViewController:alert animated:YES completion:nil];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}
 @end

