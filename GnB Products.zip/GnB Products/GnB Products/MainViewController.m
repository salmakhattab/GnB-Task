//
//  ViewController.m
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "MainViewController.h"
#import "ServiceConnector.h"
#import "DataOperation.h"
#import "Product.h"
#import "HorizontalCollectionViewCell.h"
#import "VerticalCollectionViewCell.h"
#import "DetailedViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController {
    
    DataOperation *productsOpeartion;
    ServiceConnector *serviceConnector;
    NSMutableArray *productList;
    NSMutableArray *userProductList;
    UIActivityIndicatorView *indicator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    indicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 2, [UIScreen mainScreen].bounds.size.height / 2, 1000, 1000)];
    indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
    [self.view addSubview:indicator];
    [indicator setCenter:self.view.center];
    [indicator setTranslatesAutoresizingMaskIntoConstraints:TRUE];
    [indicator setAutoresizingMask:UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin];
    [self.view bringSubviewToFront:indicator];
    [indicator setTranslatesAutoresizingMaskIntoConstraints:TRUE];
    indicator.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    productList = [NSMutableArray array];
    userProductList = [NSMutableArray array];
    [[NSUserDefaults standardUserDefaults] setObject:userProductList forKey:@"UserProductList"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    productsOpeartion = [[DataOperation alloc] init];
    serviceConnector = [[ServiceConnector alloc] init];
    productsOpeartion.url = @"http://grapesnberries.getsandbox.com/products?count=8&from=0";
    productsOpeartion.notification = @"NotificationForProducts";
    productsOpeartion.method = @"GET";
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(useNotificationForProducts:) name:productsOpeartion.notification object:nil];
    [indicator startAnimating];
    [serviceConnector executeOperation:productsOpeartion];
    __unsafe_unretained typeof(self) SELF = self;
    self.addToMyList = ^(BOOL flag, NSUInteger index){
        
        NSPropertyListFormat format;
        NSMutableDictionary *ListDic = [NSMutableDictionary dictionary];
        NSMutableArray *userList = [NSMutableArray array];
        NSString *rootPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
        NSString *plistPath = [rootPath stringByAppendingPathComponent:@"UserProductsList.plist"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:plistPath]) {
            
            plistPath = [[NSBundle mainBundle] pathForResource:@"UserProductsList" ofType:@"plist"];
        }
        NSData *plistXML = [[NSFileManager defaultManager] contentsAtPath:plistPath];
        NSDictionary *dataDict = (NSDictionary *) [NSPropertyListSerialization propertyListWithData:plistXML options:NSPropertyListMutableContainersAndLeaves format:&format error:nil];
        if(dataDict.count > 0)
        userList = dataDict[@"UserList"];
        NSMutableDictionary *productForIndex = [SELF->productList[index] mutableCopy];
        if(flag)
            [userList addObject:productForIndex];
        else {
            
            [userList removeObject:productForIndex];
        }
        [ListDic setObject:userList forKey:@"UserList"];
        productForIndex.addedToMyList = flag;
        SELF->productList[index] = [productForIndex mutableCopy];
        [SELF.allProductsCollectionview reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]]];
        [ListDic writeToFile:plistPath atomically:YES];
    };
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return collectionView == self.featuredCollectionView ? productList.count > 8 ? 8 : productList.count : productList.count;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
     
    if(collectionView == self.allProductsCollectionview) {
         
        NSMutableDictionary *productForIndex = productList[indexPath.row];
        NSString *cellText = productForIndex.productDescription;
        UIFont *cellFont = [UIFont systemFontOfSize:18.0f];
        CGSize constraintSize = CGSizeMake(self.view.bounds.size.width - 32 , MAXFLOAT);
        CGSize labelSize = [cellText boundingRectWithSize:constraintSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:cellFont} context:nil].size;
         ;
        return CGSizeMake(self.view.bounds.size.width, labelSize.height + productForIndex.height + 40);
    } else
        return CGSizeMake(self.view.bounds.size.width/5 , 100) ;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(nonnull UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
 
    //top, left, bottom, right
    return collectionView == self.featuredCollectionView ? UIEdgeInsetsMake(0, 0, 0, 16) : UIEdgeInsetsMake(0 , 0, 0, 0) ;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {

    return 5;
}
 
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *celIdentifier = collectionView == self.featuredCollectionView ? @"FeaturedCell" : @"ProductCell";
    UICollectionViewCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:celIdentifier forIndexPath:indexPath];
    if (!cell) {
        
        cell  = [collectionView dequeueReusableCellWithReuseIdentifier:celIdentifier forIndexPath:indexPath];
    }
    
    NSMutableDictionary *productForIndex = [productList[indexPath.row] mutableCopy];
    if(!productForIndex.productImage) {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSURL *imageURL = [NSURL URLWithString:productForIndex.url];
            UIImage *requestedImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:imageURL]];
            if(requestedImage) {
            
                productForIndex.productImage = [NSData dataWithContentsOfURL:imageURL];
            }
             dispatch_async(dispatch_get_main_queue(), ^{
                 
                 productList[indexPath.row] = [productForIndex mutableCopy];
                 if (collectionView == self.featuredCollectionView)
                     [self.featuredCollectionView reloadItemsAtIndexPaths:@[indexPath]];
                 else
                     [self.allProductsCollectionview reloadItemsAtIndexPaths:@[indexPath]];
             });
        });
    }
    if (collectionView == self.featuredCollectionView) {
        
        ((HorizontalCollectionViewCell *)cell).featuredImageView.image = [[UIImage alloc] initWithData:productForIndex.productImage];
    } else {
        
        [((VerticalCollectionViewCell *)cell) setProduct:[productForIndex mutableCopy]];
        ((VerticalCollectionViewCell *)cell).mainViewController = self;
        ((VerticalCollectionViewCell *)cell).index = indexPath.row;
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic =@{@"Index":@(indexPath.row) ,@"Product":productList[indexPath.row]};
    [self performSegueWithIdentifier:@"showProductDetails" sender:dic];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(NSDictionary *)dic {
    
    DetailedViewController *destViewController = segue.destinationViewController;
    destViewController.index = [dic[@"Index"] integerValue];
    destViewController.product = dic[@"Product"];
    destViewController.mainViewController = self;
}

- (void)useNotificationForProducts:(NSNotification *)notif {
    
    NSDictionary *dict = [notif userInfo];
    [indicator stopAnimating];
    NSError *error = [(DataOperation *) [dict valueForKey:@"Operation"] error];
    if (!error) {
        
        NSArray *List = [(DataOperation *) [dict valueForKey:@"Operation"] response];
        NSLog(@"%@", List);
        
        for (NSDictionary* dic in List) {
            
            NSMutableDictionary *productDict = [NSMutableDictionary dictionary];
            for (NSString* key1 in dic) {
                
                if ([dic[key1] isKindOfClass:[NSDictionary class]]) {
                    
                    for (NSString* key2 in dic[key1]) {
                        
                        [productDict setObject:dic[key1][key2] forKey:key2];
                    }
                } else {
                    
                    [productDict setObject:dic[key1] forKey:key1];
                }
            }
            [productList addObject:productDict];
        }
        [self.allProductsCollectionview reloadData];
        [self.featuredCollectionView reloadData];
    } else {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:error.description preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okButton = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [alert addAction:okButton];
        [self presentViewController:alert animated:YES completion:nil];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end

