//
//  Operation.h
//  GnB Products
//
//  Created by Salma Khattab on 8/20/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataOperation : NSObject

@property (nonatomic, readwrite) NSString *url;
@property (nonatomic, readwrite) NSString *status;
@property (nonatomic, readwrite) NSArray *response;
@property (nonatomic, strong) NSError *error;
@property (nonatomic, weak) NSOperation *operation;
@property (nonatomic, readwrite) NSString *notification;
@property (nonatomic, readwrite) NSString *method;

@end
