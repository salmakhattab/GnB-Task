//
//  HorizontalCollectionViewCell.m
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "HorizontalCollectionViewCell.h"

@implementation HorizontalCollectionViewCell

@end
