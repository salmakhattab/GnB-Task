//
//  Operation.m
//  GnB Products
//
//  Created by Salma Khattab on 8/20/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "DataOperation.h"

@implementation DataOperation

@end
