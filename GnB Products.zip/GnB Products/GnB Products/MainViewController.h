//
//  ViewController.h
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController <UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout>

@property (weak, nonatomic) IBOutlet UICollectionView *featuredCollectionView;
@property (weak, nonatomic) IBOutlet UICollectionView *allProductsCollectionview;
@property (nonatomic, copy) void(^addToMyList)(BOOL, NSUInteger);

@end

