//
//  ServiceConnector.m
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "ServiceConnector.h"

@implementation ServiceConnector

- (void) executeOperation:(DataOperation*)operation {
 
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSURL *URL = [NSURL URLWithString:operation.url];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:URL];
    [request setHTTPMethod:operation.method];
    NSCondition *condition = [[NSCondition alloc] init];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSInteger statusCode = [(NSHTTPURLResponse *) response statusCode];
        if (!error) {
            
            if (data.length > 0) {
                
                if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
                    
                    if (statusCode == 200) {
                        
                        NSLog(@"Status Code %zd", statusCode);
                        NSError *er = nil;
                        operation.response = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&er];
                        
                        if (er) {
                            operation.error = er;
                        }
                    } else {
                        
                        NSError *er = nil;
                        NSLog(@"Error %zd", statusCode);
                        NSMutableDictionary *errorDataDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&er];
                        operation.error = [NSError errorWithDomain:@"Error" code:statusCode userInfo:errorDataDictionary];
                        NSLog(@"%@", operation.error);
                        }
                }
            }
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:operation.notification object:self userInfo:@{@"Operation" : operation}];
        [condition signal];
    }];
    [condition lock];
    [task resume];
    [condition wait];
    [condition unlock];
}

@end
