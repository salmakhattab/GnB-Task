//
//  ServiceConnector.h
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "AFNetworking.h"
#import "DataOperation.h"

@interface ServiceConnector : NSObject  <NSURLSessionDelegate>

- (void) executeOperation:(DataOperation*)operation;

@end
