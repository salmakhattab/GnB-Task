//
//  DetailedViewController.h
//  GnB Products
//
//  Created by Salma Khattab on 8/22/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface DetailedViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *imageButton;
@property (weak, nonatomic) IBOutlet UIButton *twitterButton;
@property (weak, nonatomic) IBOutlet UIButton *addToMyListButton;
@property (weak, nonatomic) IBOutlet UILabel *describtionLabel;
@property (nonatomic, readwrite) NSMutableDictionary *product;
@property (nonatomic) NSInteger index;
@property (strong, nonatomic) MainViewController *mainViewController;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageHeight;

@end
