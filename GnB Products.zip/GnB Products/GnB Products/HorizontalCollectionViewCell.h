//
//  HorizontalCollectionViewCell.h
//  GnB Products
//
//  Created by Salma Khattab on 8/19/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HorizontalCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *featuredImageView;

@end
