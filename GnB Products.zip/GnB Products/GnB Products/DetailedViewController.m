//
//  DetailedViewController.m
//  GnB Products
//
//  Created by Salma Khattab on 8/22/17.
//  Copyright © 2017 Salma Khattab. All rights reserved.
//

#import "DetailedViewController.h"
#import "Product.h"

@interface DetailedViewController ()

@end

@implementation DetailedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.imageButton setBackgroundImage:[[UIImage alloc] initWithData:_product.productImage] forState:UIControlStateNormal];
    [self.imageButton setTitle:@(_product.price).description forState:UIControlStateNormal];
    self.describtionLabel.text = _product.productDescription;
    [self.addToMyListButton setTitle:@"Add to my list" forState:UIControlStateNormal];
    [self.twitterButton setTitle:@"Share" forState:UIControlStateNormal];
    self.imageHeight.constant = _product.height;
    if(!_product.productImage) {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSURL *imageURL = [NSURL URLWithString:_product.url];
            UIImage *requestedImage = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:imageURL]];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self.imageButton setBackgroundImage:requestedImage forState:UIControlStateNormal];
            });
        });
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)twitterButtonClicked:(id)sender {
    
    
}

- (IBAction)addToMylistButtonClicked:(id)sender {
    
    if(!_product.addedToMyList) {
        
        _product.addedToMyList = YES;
        if(_mainViewController.addToMyList) {
            
            _mainViewController.addToMyList(_product.addedToMyList , _index);
        }
    }
}

@end
